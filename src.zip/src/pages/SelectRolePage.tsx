// src/pages/SelectRolePage.tsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
  Container,
  Alert,
} from "@mui/material";
import { ScienceOutlined } from "@mui/icons-material";
import { useAuth } from "@/context/AuthContext";

export default function SelectRolePage() {
  const { user, selectRole } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/login", { replace: true });
    }
  }, [user, navigate]);

  // Si no hay usuario, mostrar loader
  if (!user) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  const handleSelectRole = (selectedRole: string) => {
    setLoading(true);
    selectRole(selectedRole);
    // La redirección se maneja dentro de selectRole en AuthContext
  };

  // Por ahora usamos el rol principal. Si el backend devuelve múltiples roles en el futuro,
  // puedes expandir esta lógica.
  const availableRoles = [user.role].filter(Boolean);

  return (
    <Container maxWidth="sm" sx={{ py: 8 }}>
      <Box sx={{ textAlign: "center", mb: 6 }}>
        <ScienceOutlined sx={{ fontSize: 60, color: "primary.main", mb: 2 }} />
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
          Selecciona tu rol
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Has iniciado sesión como{" "}
          <strong>
            {user.first_name} {user.last_name}
          </strong>
        </Typography>
      </Box>

      <Card sx={{ borderRadius: 3 }}>
        <CardContent sx={{ p: 4 }}>
          {availableRoles.length === 0 && (
            <Alert severity="warning" sx={{ mb: 2 }}>
              No se encontraron roles asociados a tu cuenta.
            </Alert>
          )}

          <Box sx={{ display: "flex", flexDirection: "column", gap: 2.5 }}>
            {availableRoles.map((rol, index) => (
              <Button
                key={index}
                variant="outlined"
                size="large"
                fullWidth
                disabled={loading}
                onClick={() => handleSelectRole(rol as string)}
                sx={{
                  py: 2.5,
                  justifyContent: "flex-start",
                  textAlign: "left",
                  fontSize: "1.05rem",
                  borderRadius: 2,
                }}
              >
                {rol}
              </Button>
            ))}
          </Box>
        </CardContent>
      </Card>

      <Typography
        variant="caption"
        sx={{
          display: "block",
          textAlign: "center",
          mt: 4,
          color: "text.disabled",
        }}
      >
        Puedes cambiar de rol cerrando sesión y volviendo a iniciar sesión.
      </Typography>
    </Container>
  );
}
