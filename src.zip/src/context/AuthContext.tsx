// src/context/AuthContext.tsx
import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { AuthState, LoginCredentials, User, UserRole } from "@/types";
import { authService } from "@/services/auth.service";

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  selectRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
  navigate: (path: string, options?: { replace?: boolean }) => void;
}

export function AuthProvider({ children, navigate }: AuthProviderProps) {
  const [state, setState] = useState<AuthState>({
    user: null,
    tokens: null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    const tokens = authService.getStoredTokens();
    const user = authService.getStoredUser();

    if (tokens && user) {
      setState({
        user,
        tokens,
        isAuthenticated: true,
        isLoading: false,
      });
    } else {
      setState((prev) => ({ ...prev, isLoading: false }));
    }
  }, []);

  const login = async (credentials: LoginCredentials) => {
    const { tokens, user, roles } = await authService.login(credentials);

    authService.storeAuth(tokens, user);

    setState({
      user,
      tokens,
      isAuthenticated: true,
      isLoading: false,
    });

    if (roles && roles.length > 1) {
      navigate("/select-role", { replace: true });
    } else {
      navigate("/dashboard", { replace: true });
    }
  };

  const selectRole = (selectedRole: UserRole) => {
    if (!state.user) return;

    const updatedUser: User = {
      ...state.user,
      roles: [selectedRole], // ← Guardamos solo el rol seleccionado
    };

    authService.storeUser(updatedUser);

    setState((prev) => ({
      ...prev,
      user: updatedUser,
    }));

    navigate("/dashboard", { replace: true });
  };

  const logout = async () => {
    if (state.tokens?.refresh) {
      await authService.logout(state.tokens.refresh).catch(() => {});
    }
    authService.clearAuth();
    setState({
      user: null,
      tokens: null,
      isAuthenticated: false,
      isLoading: false,
    });
    navigate("/login", { replace: true });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout, selectRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth debe usarse dentro de AuthProvider");
  }
  return context;
}
